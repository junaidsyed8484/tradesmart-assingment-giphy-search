import { Component, OnInit } from '@angular/core';
import { GiphyDataService } from '../giphy-data.service';

@Component({
  selector: 'app-giphy-search',
  templateUrl: './giphy-search.component.html',
  styleUrls: ['./giphy-search.component.css']
})
export class GiphySearchComponent implements OnInit {
 giphs = [];
  constructor(private giphydataservice: GiphyDataService) {

   }

  ngOnInit(): void {
  }

  searchGif(gif_search:string)
  {
    
  	this.giphydataservice.searchGiphs(gif_search)
        .subscribe((response:any) => {
          this.giphs=response.data;
          console.log('Data',response)
        });
  }
}
